<div class="row">
		<div class="col-md-12">
			<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
				 
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="navbar-toggler-icon"></span>
				</button> <a class="navbar-brand" href="#"><FONT SIZE='5' Color='#3FB5CF'>PT Tech Muda 4</FONT></a>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="navbar-nav">
						<li>
							 <a class="nav-link" href="index.php?hal=home"><FONT SIZE='4' color="white">Home</FONT></a>
						</li>
						<li class="nav-item">
							 <a class="nav-link" href="index.php?hal=aboutus"><FONT SIZE='4' color="white">About Us</FONT></a>
						</li>
						<li class="nav-item dropdown">
							 <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown"><FONT SIZE='4' color="white">Master Data</FONT></a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                 <a class="dropdown-item" href="index.php?hal=pegawai"><FONT SIZE='4'>Pegawai</FONT></a> 
                                 <a class="dropdown-item" href="index.php?hal=divisi"><FONT SIZE='4'>Divisi</FONT></a> 
                                 <a class="dropdown-item" href="index.php?hal=jabatan"><FONT SIZE='4'>Jabatan</FONT></a>
                                 <a class="dropdown-item" href="index.php?hal=gaji"><FONT SIZE='4'>Gaji</FONT></a>
							</div>
						</li>
					</ul>
					<ul class="navbar-nav ml-md-auto">
                    <form class="form-inline">
						<input class="form-control mr-sm-2" type="text"> 
						<button class="btn btn-primary my-2 my-sm-0" type="submit">
							Search
						</button>
					</form>
					</ul>
				</div>
			</nav>
		</div>
	</div>
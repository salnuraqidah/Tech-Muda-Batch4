<div class="row">
		<div class="col-md-12">
			
			<!-- Footer -->

<footer class="page-footer font-small mdb-color lighten-3 pt-4">

<!-- Footer Links -->
<div class="container text-center text-md-left">

  <!-- Grid row -->
  <div class="row">

	<!-- Grid column -->
	<!-- Grid column -->

	<!-- Grid column -->
	<div class="col-md-6 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

	  <!-- Contact details -->
	  
	  <h5 class="font-weight-bold text-uppercase mb-4"><img src="images/pin.png">  Address</h5>

	
		  <p>
			   Jalan Lenteng Agung Raya No.20
			   RT.5/RW.1 Lenteng Agung,
			   Srengseng Sawah, Jagakarsa, Jakarta Selatan,
			  Daerah Khusus Ibukota Jakarta 12640
		</p>
	

	
	  

	</div>
	<!-- Grid column -->

	<hr class="clearfix w-100 d-md-none">

	<!-- Grid column -->
	<div class="col-md-6 col-lg-2 text-center mx-auto my-4">

	  <!-- Social buttons -->
	  <h5 class="font-weight-bold text-uppercase mb-4">Follow Us</h5>

	  <!-- Facebook -->
	  <a type="button" class="btn-floating btn-fb" href="https://www.instagram.com/">
		<i class="fab fa-facebook-f"><img src="images/ig.png" ></i>
	  </a>
	  <!-- Twitter -->
	  <a type="button" class="btn-floating btn-tw"href="https://www.twitter.com/">
		<i class="fab fa-twitter">&nbsp;<img src="images/twitter.png" ></i>
	  </a>
	  <!-- Google +-->
	  <a type="button" class="btn-floating btn-gplus" href="https://www.facebookcom/">
		<i class="fab fa-google-plus-g">&nbsp;<img src="images/fb.png" ></i>
	  </a>

	</div>
	<!-- Grid column -->

  </div>
  <!-- Grid row -->

</div>
<!-- Footer Links -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:
  <a href="#"> PT. Tech Muda 4</a>
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->
			
		</div>
	</div>
</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>


<?php
include_once 'header.php';
include_once 'menu.php';
include_once 'koneksi.php';
include_once 'model/Pegawai.php';
include_once 'model/Divisi.php';
include_once 'model/Jabatan.php';
include_once 'model/Gaji.php';
include_once 'model/Materi.php';
include_once 'model/Jadwal.php';
include_once 'model/Login.php';
echo '<br/>';
include_once 'sidebar.php';
include_once 'main.php';
echo '<br/>';
include_once 'footer.php';
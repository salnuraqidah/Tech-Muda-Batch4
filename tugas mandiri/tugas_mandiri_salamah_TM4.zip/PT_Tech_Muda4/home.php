<div class="jumbotron">
<table cellpadding="10">
<tr>
<td rowspan="2" align="center"> <img src="images/cloud.png" width="150px">  </td>
<td> <h2><FONT Color='#3FB5CF'> Tech Muda </h2> </td>
</tr>
<tr>
<td> <p align="justify"><FONT SIZE='4'>
Tech Muda is an IT company which provides skillfull talents as IT service for our customers. Founded in 2010, we are commited to develop and upgrade human resources with specific skills and knowledge, from potential to become excellent people who is ready to compete in IT industry to help you meet your IT business objective.
</p> </FONT> </td>
</tr>

</table>
			</div>
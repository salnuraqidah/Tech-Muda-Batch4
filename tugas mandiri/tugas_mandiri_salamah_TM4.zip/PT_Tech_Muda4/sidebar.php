<div class="row">

		<div class="col-md-3">
			<div class="list-group">
				 <a href="#" class="list-group-item list-group-item-action active"><h4>Menu</h4></a>
				
				<div class="list-group-item">
				<a href="index.php?hal=login"> <h5 class="list-group-item-heading">
						User
					</h5></a>
				</div>
				<div class="list-group-item">
				<a href="index.php?hal=materi"> <h5 class="list-group-item-heading">
						Materi Diklat
					</h5></a>
				</div>
				<div class="list-group-item">
				<a href="index.php?hal=jadwal"><h5 class="list-group-item-heading">
						Jadwal Diklat
					</h5></a>
				</div>
			</div>
		</div>
		
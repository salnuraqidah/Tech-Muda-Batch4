<div class="row">
		<div class="col-md-12">
			<div class="alert alert-dismissible alert-secondary">
				<h5 align="center">
					Tech Muda Batch 4
				</h4> <strong>Design by salnuraqidah</strong> @2020 NF Computer
			</div>
		</div>
	</div>
</div>

	<script src="js/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
 <!--   <script src="js/scripts.js"></script> -->
  </body>
</html>
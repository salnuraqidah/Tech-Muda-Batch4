<div class="col-md-4">
<div class="list-group">

<h5 class="list-group-item list-group-item-action active">Pesan Tiket Disini</h5>

<form>
    <div class="form-group">
    <select class="form-control">

    <option> Stasiun Awal </option>
    <option> Jakarta </option>
    <option> Bandung </option>
    <option> Semarang </option>
    <option> Yogyakarta </option>
    </select>
    </select>
  </div>
  <div class="form-group">
    <select class="form-control">
    <option> Stasiun Tujuan </option>
    <option> Jakarta </option>
    <option> Bandung </option>
    <option> Semaraang </option>
    <option> Yogyakarta </option>
    </select>
  </div>
  <div class="form-group">
  <label for="exampleFormControlInput1">Tanggal Berangkat</label>  
  <input class="form-control" type="datetime-local">
  </div>
  <div class="form-group">
    <select class="form-control">
    <option> Jumlah </option>
    <option> 1 Dewasa </option>
    <option> 2 Dewasa </option>
    <option> 3 Dewasa </option>
    <option> 4 Dewasa </option>
    </select>
  </div>
  <div class="list-group">
  <button type="submit" class="btn btn-primary mb-2">Pesan & Cari Kereta</button>
</div>


  
</form>
</div>
</div>
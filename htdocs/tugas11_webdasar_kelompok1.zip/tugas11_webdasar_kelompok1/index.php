<?php
include_once 'header.php';
include_once 'menu.php';
include_once 'koneksi.php';
include_once 'model/Customer.php';
include_once 'model/Pesanan.php';
include_once 'model/Pembayaran.php';
include_once 'model/CheckOut.php';
echo '<br/>';
include_once 'main.php';
include_once 'sidebar.php';
echo '<br/>';
include_once 'footer.php';
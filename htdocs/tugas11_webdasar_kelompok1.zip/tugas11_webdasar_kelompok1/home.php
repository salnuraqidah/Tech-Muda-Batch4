<div class="jumbotron">
	<h2> Why book with Tiketku? </h2>
	<table cellpadding=15>
		<tr> 
			<td> <img src="images/sale.png">  </td>
			<td>  <h4> Honest Price </h4> 
			<p> No transaction fee. No hidden charges </p> </td>
		</tr>
		<tr> 
			<td> <img src="images/discount.png">  </td>
			<td>  <h4> Special Discounts </h4> 
			<p> Special discounted for train customers, newsletter subscribers and Tiketku members </p></td>
		</tr>
		<tr> 
			<td> <img src="images/payment.png">  </td>
			<td>  <h4> Various Payment Options </h4> 
			<p> Be more flexible with various payment methods from ATM Transfer to Virtual Account </p></td>
		</tr>
	</table>
</div>
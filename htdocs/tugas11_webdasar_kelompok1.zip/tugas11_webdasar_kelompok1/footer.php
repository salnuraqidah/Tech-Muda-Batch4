<div class="row">
		<div class="col-md-12">
			
			<div class="alert alert-dismissible alert-primary">
				 
			<h6 align="center"> Design by Kelompok 1 &copy; Tech Muda Batch 4</h6> 
			</div>
			
		</div>
	</div>
</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>


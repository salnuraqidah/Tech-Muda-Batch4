-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2019 at 05:57 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbpenjadwalan`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Admin', '2', 1543391661),
('Admin', '4', 1550547307),
('Admin', '5', 1552025662),
('Admin', '6', 1552025652),
('Admin Permission ', '4', 1543076982),
('Administrator ', '4', 1543076982),
('karyawan', '3', 1543434521),
('staff', '7', 1552028010);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/*', 2, NULL, NULL, NULL, 1543044890, 1543044890),
('/admin/*', 2, NULL, NULL, NULL, 1543044963, 1543044963),
('/admin/assignment/*', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/assignment/assign', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/assignment/index', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/assignment/revoke', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/assignment/view', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/default/*', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/default/index', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/menu/*', 2, NULL, NULL, NULL, 1543044945, 1543044945),
('/admin/menu/create', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/menu/delete', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/menu/index', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/menu/update', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/menu/view', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/admin/permission/*', 2, NULL, NULL, NULL, 1543044947, 1543044947),
('/admin/permission/assign', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/permission/create', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/permission/delete', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/permission/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/permission/remove', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/permission/update', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/permission/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/role/*', 2, NULL, NULL, NULL, 1543044950, 1543044950),
('/admin/role/assign', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/role/create', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/role/delete', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/role/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/role/remove', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/role/update', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/role/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/route/*', 2, NULL, NULL, NULL, 1543044952, 1543044952),
('/admin/route/assign', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/route/create', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/route/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/route/refresh', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/route/remove', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/rule/*', 2, NULL, NULL, NULL, 1543044957, 1543044957),
('/admin/rule/create', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/rule/delete', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/rule/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/rule/update', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/rule/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/*', 2, NULL, NULL, NULL, 1543044961, 1543044961),
('/admin/user/activate', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/change-password', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/delete', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/login', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/logout', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/request-password-reset', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/reset-password', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/signup', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/admin/user/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/debug/*', 2, NULL, NULL, NULL, 1543044970, 1543044970),
('/debug/default/*', 2, NULL, NULL, NULL, 1543044965, 1543044965),
('/debug/default/db-explain', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/debug/default/download-mail', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/debug/default/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/debug/default/toolbar', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/debug/default/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/debug/user/*', 2, NULL, NULL, NULL, 1543044967, 1543044967),
('/debug/user/reset-identity', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/debug/user/set-identity', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/file/*', 2, NULL, NULL, NULL, 1543044975, 1543044975),
('/file/download', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/file/show', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/gii/*', 2, NULL, NULL, NULL, 1543044972, 1543044972),
('/gii/default/*', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/gii/default/action', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/gii/default/diff', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/gii/default/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/gii/default/preview', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/gii/default/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/*', 2, NULL, NULL, NULL, 1543044979, 1543044979),
('/jadwaltraining/create', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/delete', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/export-excel-pengajar', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/surat-tugas-asisten', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/surat-tugas-mengajar', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/update', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jadwaltraining/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jeniskelas/*', 2, NULL, NULL, NULL, 1543044982, 1543044982),
('/jeniskelas/create', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jeniskelas/delete', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jeniskelas/index', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jeniskelas/update', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/jeniskelas/view', 2, NULL, NULL, NULL, 1543429408, 1543429408),
('/kategori/*', 2, NULL, NULL, NULL, 1543044984, 1543044984),
('/kategori/create', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/kategori/delete', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/kategori/index', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/kategori/update', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/kategori/view', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/klien/*', 2, NULL, NULL, NULL, 1543044987, 1543044987),
('/klien/create', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/klien/delete', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/klien/index', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/klien/update', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/klien/view', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/materi/*', 2, NULL, NULL, NULL, 1543044989, 1543044989),
('/materi/create', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/materi/delete', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/materi/index', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/materi/update', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/materi/view', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/pengajar/*', 2, NULL, NULL, NULL, 1543044991, 1543044991),
('/pengajar/create', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/pengajar/delete', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/pengajar/export-excel-pengajar', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/pengajar/export-pdf-pengajar', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/pengajar/index', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/pengajar/update', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/pengajar/view', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/site/*', 2, NULL, NULL, NULL, 1543044994, 1543044994),
('/site/about', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/site/captcha', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/site/contact', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/site/error', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/site/index', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/site/login', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/site/logout', 2, NULL, NULL, NULL, 1543429409, 1543429409),
('/user/*', 2, NULL, NULL, NULL, 1543044936, 1543044936),
('/user/admin/*', 2, NULL, NULL, NULL, 1543044923, 1543044923),
('/user/admin/assignments', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/block', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/confirm', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/create', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/delete', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/index', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/info', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/resend-password', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/switch', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/update', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/admin/update-profile', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/profile/*', 2, NULL, NULL, NULL, 1543044925, 1543044925),
('/user/profile/index', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/profile/show', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/recovery/*', 2, NULL, NULL, NULL, 1543044927, 1543044927),
('/user/recovery/request', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/recovery/reset', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/registration/*', 2, NULL, NULL, NULL, 1543044930, 1543044930),
('/user/registration/confirm', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/registration/connect', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/registration/register', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/registration/resend', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/security/*', 2, NULL, NULL, NULL, 1543044932, 1543044932),
('/user/security/auth', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/security/login', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/security/logout', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/settings/*', 2, NULL, NULL, NULL, 1543044934, 1543044934),
('/user/settings/account', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/settings/confirm', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/settings/delete', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/settings/disconnect', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/settings/networks', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('/user/settings/profile', 2, NULL, NULL, NULL, 1543429407, 1543429407),
('Admin', 1, NULL, NULL, NULL, 1543044910, 1543390556),
('Admin Permission ', 2, NULL, NULL, NULL, 1543045027, 1543045027),
('staff', 1, NULL, NULL, NULL, 1543390683, 1552025961),
('staff permission', 2, NULL, NULL, NULL, 1543429386, 1552025895);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('Admin', '/*'),
('Admin', '/admin/*'),
('Admin', '/admin/menu/*'),
('Admin', '/admin/permission/*'),
('Admin', '/admin/role/*'),
('Admin', '/admin/route/*'),
('Admin', '/admin/rule/*'),
('Admin', '/admin/user/*'),
('Admin', '/debug/*'),
('Admin', '/debug/default/*'),
('Admin', '/debug/user/*'),
('Admin', '/file/*'),
('Admin', '/gii/*'),
('Admin', '/jadwaltraining/*'),
('Admin', '/jeniskelas/*'),
('Admin', '/kategori/*'),
('Admin', '/klien/*'),
('Admin', '/materi/*'),
('Admin', '/pengajar/*'),
('Admin', '/site/*'),
('Admin', '/user/*'),
('Admin', '/user/admin/*'),
('Admin', '/user/profile/*'),
('Admin', '/user/recovery/*'),
('Admin', '/user/registration/*'),
('Admin', '/user/security/*'),
('Admin', '/user/settings/*'),
('Admin', 'Admin Permission '),
('Admin Permission ', '/*'),
('Admin Permission ', '/admin/*'),
('Admin Permission ', '/admin/menu/*'),
('Admin Permission ', '/admin/permission/*'),
('Admin Permission ', '/admin/role/*'),
('Admin Permission ', '/admin/route/*'),
('Admin Permission ', '/admin/rule/*'),
('Admin Permission ', '/admin/user/*'),
('Admin Permission ', '/debug/*'),
('Admin Permission ', '/debug/default/*'),
('Admin Permission ', '/debug/user/*'),
('Admin Permission ', '/file/*'),
('Admin Permission ', '/gii/*'),
('Admin Permission ', '/jadwaltraining/*'),
('Admin Permission ', '/jeniskelas/*'),
('Admin Permission ', '/kategori/*'),
('Admin Permission ', '/klien/*'),
('Admin Permission ', '/materi/*'),
('Admin Permission ', '/pengajar/*'),
('Admin Permission ', '/site/*'),
('Admin Permission ', '/user/*'),
('Admin Permission ', '/user/admin/*'),
('Admin Permission ', '/user/profile/*'),
('Admin Permission ', '/user/recovery/*'),
('Admin Permission ', '/user/registration/*'),
('Admin Permission ', '/user/security/*'),
('Admin Permission ', '/user/settings/*'),
('staff', 'staff permission'),
('staff permission', '/jadwaltraining/index'),
('staff permission', '/jadwaltraining/view'),
('staff permission', '/jeniskelas/index'),
('staff permission', '/jeniskelas/view'),
('staff permission', '/kategori/index'),
('staff permission', '/kategori/view'),
('staff permission', '/klien/index'),
('staff permission', '/klien/view'),
('staff permission', '/materi/index'),
('staff permission', '/materi/view'),
('staff permission', '/pengajar/index'),
('staff permission', '/pengajar/view');

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `detail_jadwal`
--

CREATE TABLE `detail_jadwal` (
  `id` int(11) NOT NULL,
  `idjadwal` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_jadwal`
--

INSERT INTO `detail_jadwal` (`id`, `idjadwal`, `tgl`, `keterangan`) VALUES
(71, 54, '2019-03-18', 'Pengantar PHP,Variabel,Struktur Kendali'),
(72, 54, '2019-03-19', 'Switch Case, Looping'),
(73, 54, '2019-03-20', 'Array Scalar, Array Assoiative'),
(74, 54, '2019-03-21', 'OOP'),
(75, 54, '2019-03-22', 'Database MySQL'),
(76, 54, '2019-03-25', 'PDO'),
(77, 54, '2019-03-26', 'Studi Kasus : Template RWD Bootstrap'),
(78, 54, '2019-03-27', 'Studi Kasus : CRUD'),
(79, 54, '2019-03-28', 'Studi Kasus : Session'),
(80, 54, '2019-03-29', 'Studi Kasus : Upload Web Hosting'),
(81, 53, '2019-03-08', ''),
(82, 53, '2019-03-11', ''),
(83, 53, '2019-03-12', ''),
(84, 53, '2019-03-13', ''),
(85, 53, '2019-03-14', ''),
(86, 53, '2019-03-15', ''),
(90, 55, '2019-03-13', ''),
(91, 55, '2019-03-14', ''),
(92, 55, '2019-03-15', ''),
(93, 56, '2019-03-18', ''),
(94, 56, '2019-03-25', ''),
(95, 56, '2019-03-26', ''),
(96, 57, '2019-03-27', ''),
(97, 57, '2019-03-28', ''),
(98, 57, '2019-03-29', ''),
(99, 57, '2019-04-01', ''),
(105, 52, '2019-03-04', 'Struktur Kendali Python'),
(106, 52, '2019-03-05', 'Looping dan Array'),
(107, 52, '2019-03-06', 'OOP'),
(108, 51, '2019-02-28', 'Pengantar Algoritma dan Pemrograman'),
(109, 51, '2019-03-01', 'Pengantar Pemrogaman Python'),
(110, 45, '2019-02-27', ''),
(111, 44, '2019-02-25', ''),
(112, 44, '2019-02-26', ''),
(113, 47, '2019-02-25', ''),
(117, 48, '2019-02-25', ''),
(118, 48, '2019-02-26', ''),
(119, 48, '2019-02-27', ''),
(120, 43, '2019-02-20', ''),
(121, 43, '2019-02-22', '');

-- --------------------------------------------------------

--
-- Table structure for table `jadwaltraining`
--

CREATE TABLE `jadwaltraining` (
  `id` int(11) NOT NULL,
  `idPengajar` int(11) NOT NULL,
  `asisten` varchar(30) DEFAULT NULL,
  `idMateri` int(11) NOT NULL,
  `idJenisKelas` int(11) NOT NULL,
  `idKlien` int(11) NOT NULL,
  `tglMulai` date NOT NULL,
  `tglAkhir` date NOT NULL,
  `hariBerjalan` text,
  `jamAkhir` time NOT NULL,
  `jamMulai` time NOT NULL,
  `durasi` float NOT NULL,
  `lokasi` text NOT NULL,
  `jmlPeserta` int(11) DEFAULT NULL,
  `deskripsi` text,
  `tgl_input` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwaltraining`
--

INSERT INTO `jadwaltraining` (`id`, `idPengajar`, `asisten`, `idMateri`, `idJenisKelas`, `idKlien`, `tglMulai`, `tglAkhir`, `hariBerjalan`, `jamAkhir`, `jamMulai`, `durasi`, `lokasi`, `jmlPeserta`, `deskripsi`, `tgl_input`) VALUES
(3, 29, 'Syaiful Ramadhan', 2, 2, 3, '2018-01-08', '2018-04-23', '-', '15:10:00', '09:50:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(4, 30, 'Ahmad Arip', 2, 2, 3, '2018-01-08', '2018-04-23', '-', '15:10:00', '09:50:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(5, 32, 'Ahmad Arip', 2, 2, 3, '2018-01-09', '2018-04-28', '', '11:20:00', '08:00:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(6, 30, 'Hamdan Ainul Atmam Alfaruqi', 2, 2, 3, '2018-01-09', '2018-04-24', '-', '11:20:00', '08:00:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(7, 18, 'M. Luqni Baihaqi', 50, 2, 3, '2018-01-10', '2018-04-25', '-', '15:10:00', '09:50:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(8, 33, 'Syaiful ramadhan', 50, 2, 3, '2018-01-10', '2018-04-25', '-', '15:10:00', '09:50:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(9, 18, 'M. Luqni Baihaqi', 33, 2, 3, '2018-01-11', '2018-04-26', '-', '11:20:00', '08:00:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(10, 34, 'Nanang Kuswara', 33, 2, 3, '2018-01-11', '2018-04-26', '-', '11:20:00', '08:00:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(11, 35, '-', 75, 2, 3, '2018-01-11', '2018-04-26', '-', '15:10:00', '13:30:00', 23, 'Pesantren TIK', 25, '-', '0000-00-00'),
(12, 36, 'Hamdan Ainul Atmam Alfaruqi', 76, 2, 3, '2018-01-12', '2018-04-27', '-', '11:20:00', '08:00:00', 46, 'Pesantren TIK', 25, '-', '0000-00-00'),
(13, 37, 'Dudi Fitrahadi', 76, 2, 3, '2018-01-12', '2018-04-27', '-', '11:20:00', '08:00:00', 47, 'Pesantren TIK', 25, '-', '0000-00-00'),
(14, 38, '-', 77, 1, 4, '2018-02-07', '2018-02-08', '7&8 februari 2018', '16:30:00', '08:30:00', 14, 'Jalan Penjernihan II no.2, Jakpus', 25, '-', '0000-00-00'),
(16, 18, '-', 78, 2, 4, '2018-02-14', '2018-02-15', '14 dan 15 februari 2018', '16:30:00', '08:30:00', 14, 'Jalan Penjernihan II no.2, Jakpus', 25, '-', '0000-00-00'),
(17, 6, '-', 79, 2, 5, '2018-01-24', '2018-01-25', '24 dan 25 Januari 2018', '17:00:00', '09:00:00', 20, 'Sahid Eminence Hotel Cianjur', 25, '-', '0000-00-00'),
(18, 29, '-', 14, 1, 6, '2018-01-23', '2018-02-01', '23, 25, 30 Januari 2018 dan 1 februari 2018', '12:00:00', '08:00:00', 16, 'Kampus B', 25, '-', '0000-00-00'),
(19, 32, '-', 3, 1, 6, '2018-01-21', '2018-03-11', '-', '12:00:00', '08:00:00', 32, 'Kampus B', 25, '-', '0000-00-00'),
(20, 32, '-', 3, 3, 6, '2018-02-12', '2018-03-19', '12, 13, 19, 20, 26, 27 Februari 2018 s/d 5,6, 12, 13, 19 Maret 2018\r\n', '20:00:00', '17:00:00', 33, 'Graha Perusahaam Negara', 25, '-', '0000-00-00'),
(21, 18, '-', 35, 1, 6, '2018-02-18', '2018-05-06', '-', '12:00:00', '08:00:00', 44, 'Kampus B', 25, '-', '0000-00-00'),
(22, 39, '-', 81, 2, 7, '2018-02-19', '2018-03-16', '19 dan 20 februari 2018\r\n15 dan 16 februari 2018', '17:00:00', '08:00:00', 32, 'Hotel Haris Sentul', 25, '-', '0000-00-00'),
(23, 7, '-', 82, 2, 7, '2018-02-22', '2018-03-06', '22 dan 23 februari 2018\r\n5 dan 6 maret 2018', '17:00:00', '08:00:00', 32, 'Hotel Haris Sentul', 25, '-', '0000-00-00'),
(24, 7, '-', 83, 2, 7, '2018-03-08', '2018-03-28', '8 dan 9 maret 2018\r\n29 maret 2018', '17:00:00', '08:00:00', 32, 'Hotel Haris Sentul', 25, '-', '0000-00-00'),
(25, 29, '-', 3, 2, 8, '2018-02-27', '2018-03-13', '27 februari 2018 dan 13 maret 2018', '17:00:00', '08:00:00', 16, 'PT. Nusa Inti Artha (DOKU)', 25, '-', '0000-00-00'),
(26, 32, '-', 3, 2, 8, '2018-03-02', '2018-03-09', '2 maret 2018 dan 9 maret 2018', '17:00:00', '08:00:00', 16, 'PT. Nusa Inti Artha (DOKU)', 25, '-', '0000-00-00'),
(27, 4, '-', 84, 2, 5, '2018-03-01', '2018-03-01', 'Kamis', '17:00:00', '09:00:00', 8, 'PT. Kementerian PU dan PR', 25, '-', '2018-03-01'),
(28, 18, '-', 43, 2, 10, '2018-03-06', '2018-03-23', '6,9,13,14,23 maret 2018', '21:00:00', '18:00:00', 14, 'PT. Nusapro Telemedia Persada', 25, '-', '2018-03-06'),
(29, 18, '', 59, 2, 40, '2019-01-07', '2019-01-09', 'Senin,Selasa,Rabu', '16:00:00', '08:00:00', 20, 'Lapangan Tembak Cibubur Jaktim', 7, '', '2019-03-08'),
(30, 26, '', 85, 1, 41, '2019-01-02', '2019-01-04', 'Rabu,Kamis,Jum\'at', '17:30:00', '13:30:00', 12, 'Kampus B STT NF', 10, '', '2019-01-02'),
(31, 23, 'Laisa Nurin Mentari, S.Kom', 78, 2, 42, '2019-01-16', '2019-01-17', 'Rabu,Kamis', '15:00:00', '10:00:00', 8, 'Plaza Indonesia', 17, '', '2019-01-16'),
(32, 20, '', 78, 2, 43, '2019-01-07', '2019-01-09', 'Senin,Selasa,Rabu', '17:00:00', '13:00:00', 12, 'Tanjung Priok Jakarta Utara', NULL, '', '2019-03-08'),
(33, 32, '', 3, 1, 41, '2019-01-06', '2019-02-24', 'Setiap hari Minggu tanggal : 6, 13, 20, 27 Januari, 3, 10, 17, 24 Februari 2019', '12:00:00', '08:00:00', 32, 'Kampus B STT-NF', NULL, '', '2019-01-06'),
(34, 25, '', 41, 1, 41, '2019-01-05', '2019-03-23', 'Setiap hari Sabtu tanggal : 5, 12, 19, 26 Januari, 2, 9,16, 23 Februari 2019 ', '12:00:00', '08:00:00', 32, 'Kampus B207', NULL, '', '2019-03-08'),
(35, 23, '', 77, 2, 44, '2019-01-15', '2019-01-15', 'Selasa', '12:00:00', '09:00:00', 3, 'RDTX, Tower Mega Kuningan', NULL, '', '2019-03-08'),
(36, 10, '', 55, 3, 41, '2019-01-29', '2019-01-29', 'Selasa', '17:00:00', '14:00:00', 3, 'B207', 1, '', '2019-03-08'),
(37, 18, '', 35, 1, 41, '2019-01-27', '2019-04-07', 'Setiap hari Minggu tanggal : 27 Januari, 3, 10, 17, 24 Februari, 3, 10, 17, 24, 31 Maret, 7 April 2019', '12:00:00', '08:00:00', 40, 'B106', 5, '', '2019-03-08'),
(38, 41, '', 55, 3, 41, '2019-01-31', '2019-01-31', 'Kamis', '17:00:00', '14:00:00', 3, 'B206', 1, 'Web Service', '2019-03-08'),
(39, 18, '', 56, 3, 41, '2019-02-04', '2019-02-25', 'Bulan Februari tanggal 4, 6, 12 dan 25 Februari 2019', '17:00:00', '14:00:00', 12, 'B207', 1, 'Web Service', '2019-03-08'),
(40, 11, '', 31, 2, 4, '2019-02-07', '2019-02-08', 'Kamis,Jum\'at', '17:30:00', '08:30:00', 16, 'Bendungan Hilir Jakarta Pusat', NULL, '', '2019-03-08'),
(41, 23, '', 78, 2, 11, '2019-02-12', '2019-02-15', 'Hari Selasa - Jum\'at : 12,13,14,15 Februari 2019', '16:00:00', '09:00:00', 24, 'Kemayoran Jakarta', NULL, 'Excel Dashboard', '2019-03-08'),
(43, 20, 'Yolanda Erziana, A.Md.', 80, 8, 45, '2019-02-20', '2019-03-22', 'Rabu,Jum\'at', '12:00:00', '08:00:00', 8, 'Kampus A Lantai 4', 30, 'Literasi Komputer', '2019-03-19'),
(44, 24, 'Yolanda Erziana, A.Md.', 80, 8, 45, '2019-02-25', '2019-02-26', 'Senin,Selasa', '12:00:00', '08:00:00', 8, 'Kampus A Lantai 4', 30, 'Literasi Komputer Sekolah Programmer', '2019-03-19'),
(45, 24, 'Yuliadi,A.Md.', 80, 8, 45, '2019-02-27', '2019-02-27', 'Rabu', '12:00:00', '08:00:00', 4, 'Kampus A Lantai 4', 30, 'Literasi Komputer Sekolah Pemrograman', '2019-03-19'),
(46, 24, '', 80, 4, 41, '2019-02-18', '2019-03-23', 'Senin s/d Sabtu', '17:30:00', '13:00:00', 24, 'B206', 2, '', '2019-03-08'),
(47, 42, '', 18, 2, 46, '2019-02-25', '2019-02-25', 'Senin', '17:00:00', '08:00:00', 8, 'Universitas Mercubuana', NULL, 'Pelatihan Administrasi Perkantoran &  5S', '2019-03-19'),
(48, 20, '', 80, 4, 47, '2019-02-25', '2019-02-27', 'Senin,Selasa,Rabu', '17:00:00', '08:00:00', 24, 'B207', NULL, 'IHT Ms. Office Badan Siber dan Sandi Negara', '2019-03-19'),
(51, 18, 'Laisa Nurin Mentari,S.Kom.', 86, 8, 45, '2019-02-28', '2019-03-01', 'Kamis,Jum\'at', '12:00:00', '08:00:00', 8, 'Kampus A Lantai 4', 30, 'Pengantar Pemrograman Sekolah Programmer', '2019-03-19'),
(52, 18, 'Sugandi, S.T.', 86, 8, 45, '2019-03-04', '2019-03-06', 'Senin,Selasa,Rabu', '12:00:00', '08:00:00', 12, 'Kampus A Lantai 4', 30, 'Pengantar Pemrograman Sekolah Programmer', '2019-03-19'),
(53, 24, 'Yuliadi,A.Md.', 33, 8, 45, '2019-03-08', '2019-03-15', '', '12:00:00', '08:00:00', 24, 'Kampus A Lantai 4', 30, 'Pemograman Web Dasar Sekolah Programmer', '2019-03-12'),
(54, 18, 'Yuliadi,A.Md.', 35, 8, 45, '2019-03-18', '2019-03-29', 'Senin s/d Jum\'at', '12:00:00', '08:00:00', 38, 'Kampus A Lantai 4', 30, 'Pemograman Web Lanjutan Sekolah Programmer', '2019-03-12'),
(55, 26, '', 74, 2, 27, '2019-03-13', '2019-03-15', 'Rabu,Kamis,Jum\'at', '11:00:00', '08:00:00', 12, 'Kampus B STT-NF', NULL, 'IHT Photoshop Gegana Brimob Polri', '2019-03-19'),
(56, 22, '', 74, 2, 27, '2019-03-18', '2019-03-26', 'Senin,Selasa', '12:00:00', '08:00:00', 12, 'Kampus B STT-NF', NULL, 'IHT CorelDraw Gegana Brimob Polri', '2019-03-19'),
(57, 27, '', 74, 2, 27, '2019-03-27', '2019-04-01', 'Senin,Selasa,Kamis,Jum\'at', '12:00:00', '08:00:00', 16, 'Kampus B STT-NF', NULL, 'IHT Video Editing Gegana Brimob Polri', '2019-03-19');

-- --------------------------------------------------------

--
-- Stand-in structure for view `jadwaltraining_v`
-- (See below for the actual view)
--
CREATE TABLE `jadwaltraining_v` (
`kategori` varchar(45)
,`materi` varchar(255)
,`tglMulai` date
,`tglAkhir` date
,`hariBerjalan` text
,`jamMulai` time
,`jamAkhir` time
,`durasi` float
,`lokasi` text
,`jmlPeserta` int(11)
,`pengajar` varchar(45)
,`asisten` varchar(30)
,`jenis_kelas` varchar(45)
,`klien` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `jeniskelas`
--

CREATE TABLE `jeniskelas` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `deskripsi` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jeniskelas`
--

INSERT INTO `jeniskelas` (`id`, `nama`, `deskripsi`) VALUES
(1, 'public', ''),
(2, 'In House Training ', ''),
(3, 'Private', ''),
(4, 'Exclusive', ''),
(5, 'Workshop', ''),
(6, 'Seminar', ''),
(7, 'School', ''),
(8, 'Sekolah Programmer', '');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`, `deskripsi`) VALUES
(1, 'NETWORKING PACKAGES', ''),
(2, 'TECHNICIAN PACKAGES', ''),
(3, 'OFFICE APPLICATION PACKAGES', ''),
(4, 'PROFESSIONAL PACKAGES', ''),
(5, 'TECHNIC DESIGN PACKAGES', ''),
(6, 'WEB PROGRAM', ''),
(7, 'PROGRAM BERBASIS FRAMEWORK', ''),
(8, 'PROGRAM JAVA & ANDROID ', ''),
(9, 'DATABASE PACKAGES', ''),
(10, 'MULTIMEDIA & GRAPHIC DESIGN PACKAGES', ''),
(11, 'Linux & Networking', ''),
(13, 'Progamming', '');

-- --------------------------------------------------------

--
-- Table structure for table `klien`
--

CREATE TABLE `klien` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text,
  `email` varchar(45) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `klien`
--

INSERT INTO `klien` (`id`, `nama`, `alamat`, `email`, `hp`) VALUES
(3, 'PeTIK', '', '', ''),
(4, 'PT. PAM Lyonaisse Jaya', '', '', ''),
(5, 'Kementerian PUPR', '', '', ''),
(6, 'Perseorangan', '', '', ''),
(7, 'BIG (Badan Informasi Geoportal)', '', '', ''),
(8, 'PT. Nusa Inti Artha(DOKU)', '', '', ''),
(9, 'PT. Kementerian PU & PR', '', '', ''),
(10, 'PT. Nusapro Telemedia Persada', '', '', ''),
(11, 'Direktorat Navigasi Penerbangan Kemenhub', '', '', ''),
(12, 'Biro Kepegawaian Dikdasmen Kemendikbud', '', '', ''),
(13, 'Kementerian Hukum dan Ham', '', '', ''),
(14, 'PT. Komatsu Indonesia', '', '', ''),
(15, 'Mabes TNI', '', '', ''),
(16, 'Balai Pemasyarakatan Klas 1, Jakarta Selatan', '', '', ''),
(17, 'Kementerian Keuangan', '', '', ''),
(18, 'STMIK GI MDP Palembang', '', '', ''),
(19, 'Direktorat Navigasi Penerbangan Kementerian Perhubungan RI', '', '', ''),
(20, 'Tirta Asarta PDAM Kota Depok', '', '', ''),
(21, 'Daskrimti Kejaksaan Agung RI', '', '', ''),
(22, 'Universitas Indonesia', '', '', ''),
(23, 'Badan Informasi Geospasial (BIG)', '', '', ''),
(24, 'Bank Kesejahteraan Ekonomi', '', '', ''),
(25, 'Kemendikbud Dirjen Pendidikan Dasar & Menengah', '', '', ''),
(26, 'Tokio Marine Life Insurance', '', '', ''),
(27, 'Pasukan Gegana Brimob Mabes Polri', '', '', ''),
(28, 'PT. BD Indonesia', '', '', ''),
(29, 'PT. Nusapro Telemedia Persada', '', '', ''),
(30, 'LIPI Biologi', '', '', ''),
(31, 'Itjen Kemendikbud', '', '', ''),
(32, 'Direktorat PSMA Dikdasmen Kemendikbud', '', '', ''),
(33, 'Direktorat Jenderal Perimbangan Keuangan (DJPK)', '', '', ''),
(34, 'PT. Kinarya AlihDaya', '', '', ''),
(35, 'Kemendikbud', '', '', ''),
(36, 'PT. Kinarya AlihDaya', '', '', ''),
(37, 'Direktorat Jenderal Perimbangan Keuangan (DJPK)', '', '', ''),
(38, 'PT. Trakindo', '', '', ''),
(39, 'PT. Bumi Suksesindo', '', '', ''),
(40, 'PT. APS Indonesia', 'Cibubur Jakarta Timur', '', ''),
(41, 'Umum', '', '', ''),
(42, 'PT. Itochu', 'Plaza Indonesia', '', ''),
(43, 'PT. Pelabuhan Indonesia', '', '', ''),
(44, 'JD.ID', '', '', ''),
(45, 'YBM PLN', '', '', ''),
(46, 'Biro SDM Universitas Mercubuana', '', '', ''),
(47, 'Badan Siber dan Sandi Negara', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `materi`
--

CREATE TABLE `materi` (
  `id` int(11) NOT NULL,
  `kode` varchar(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `idKategori` int(11) NOT NULL,
  `durasi` float NOT NULL,
  `deskripsi` text,
  `note` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `materi`
--

INSERT INTO `materi` (`id`, `kode`, `nama`, `idKategori`, `durasi`, `deskripsi`, `note`) VALUES
(1, 'LIN1', 'Linux Basic', 1, 12, 'Materi training Linux Basic ini memfokuskan pada pengenalan dan penggunaan sistem operasi linux untuk workstation dan desktop. Peserta diberikan pemahaman tentang sistem operasi linux dan distribusi linux, peserta juga diajarkan bagaimana menginstal sistem operasi linux, serta bagaimana mngelola file dan direktori di linux, mengenal beberapa perintah-perintah dasar yang sering digunakan di linux, mengenal teks editor vi, serta diajarkan bagaimana bekerja dalam lingkungan teks mode maupun graphical mode (X window) di linux', ''),
(2, 'LIN2', 'Linux System Administration & Networking ', 1, 20, 'Linux System Administration & Networking – Materi training ini memfokuskan pada penerapan dan penggunaan sistem operasi linux untuk server. Peserta diberikan pemahaman tentang cara kerja dan proses boot di linux, peserta juga diajarkan bagaiman mengeloa user dan group, menginstal dan menguninstal software rpm dan tarball, peserta diajarkan mengkonfigurasi jaringan, membuat gateway dan internet sharing. Dan peserta diajarkan dan dibimbing menginstal dan mengkonfigurasi aplikasi-aplikasi server seperti dns, http, smtp, pop3, imap, webmail, file server dan PDC, serta web proxy.', ''),
(3, 'LIN3', 'Linux Complete (LIN1+LIN2)', 1, 32, 'Linux Complete – Materi training merupakan gabungan materi Linux Basic dan Linux System Administration & Networking sehingga peserta mampu menguasai Linux dengan cepat dan tidak setengah-setengah dalam penguasaan materinya.', ''),
(4, 'LIN4', 'Linux Security', 1, 20, 'Linux Security – Materi training ini merupakan materi lanjutan Linux Basic dan Linux System Administration & Networking (Linux Complete). Melalui materi ini, para peserta akan diperkenalkan berbagai macam faktor keamanan dalam membangun sistem komputer ~ terutama yang berbasis Open Source.', ''),
(5, 'LIN5', 'Linux Shell Programming ', 1, 20, 'Materi training ini memfokuskan pada fungsi shell sebagai bahasa pemrograman. Peserta diberikan pemahaman tentang fungsi shell, fitur-fitur dari sebuah shell dan cara menggunakan shell sebagai bahasa pemrograman.\r\n\r\n', ''),
(6, 'CISCO1', 'CISCO : Rounting & Switching Implementation', 1, 32, 'Training ini dipersiapkan untuk memberikan bekal pengetahuan mengenai jaringan komputer dan perencanaan serta pengembangan jaringan komputer yang menggunakan perangkat jaringan enterprise seperti router dan manageable switch khususnya produk router dan switch CISCO.', ''),
(7, 'CISCO2', 'CISCO CCNA Fast Track', 1, 16, 'Training ini dipersiapkan untuk memberikan bekal pengetahuan praktis mengenai jaringan komputer dan pengembangan jaringan komputer yang menggunakan perangkat router dan switch cisco. Training ini juga dipersiapkan untuk memperoleh sertifikasi CCNA.', ''),
(8, 'MIKRO1', 'MikroTik Fundamental', 1, 28, 'MikroTIK Fundamental  adalah sistem operasi dan perangkat lunak yang dapat digunakan untuk menjadikan komputer menjadi router network yang handal, mencakup berbagai fitur yang dibuat untuk ip network dan jaringan wireless, cocok digunakan oleh ISP dan provider hotspot.', ''),
(9, 'MIKRO2', 'MikroTik Advanced', 1, 40, 'Mikrotik RouterOS adalah sistem operasi dan perangkat lunak yang dapat digunakan untuk menjadikan komputer menjadi router network yang handal, mencakup berbagai fitur yang dibuat untuk ip network dan jaringan wireless, cocok digunakan oleh ISP dan provider hotspot.\r\n\r\nPerlatihan ini merupakan pelatihan lanjutan dari fitur-fitur Mikrotik seperti metode upgrade, routing, switching, VPN, wireless, firewall dan QoS.', ''),
(10, 'HUAWEI1', 'Huawei Rounting & Switching Implementation (HRSI)', 1, 32, '', ''),
(11, 'HUAWEI2', 'Huawei Certifieid Datacom Associate - Huawei Networking Teknologies & Device (HCDA-HNTD)', 1, 42, '', ''),
(12, 'JUNOS1', 'Juniper Junos (JNCIA-Junos Bootcamp)', 1, 15, 'Juniper Junos – Mengapa mengikuti JNCIA-Junos Bootcamp?\r\n\r\nJadwal pilihan 2 hari Full-Time atau 5 sesi Part-Time\r\nTraining dengan 50% lab dan 50% teori\r\nHands-on menggunakan real juniper router\r\nDiberikan waktu 30 menit untuk sholat wajib berjamaah (bagi muslim)\r\nRuangan kelas aman dan nyaman', ''),
(13, 'EHACK', 'Ethical Hacking', 1, 32, '', ''),
(14, 'TEK1', 'PC Assembling, LAN & WIreless LAN ', 2, 16, 'PC Assembling & LAN Materi training Merakit PC dan Jaringan ini memfokuskan pada pengenalan perangkat keras suatu komputer dan cara merakitnya menjadi suatu komputer yang lengkap. Peserta diberikan pemahaman tentang komponen perangkat keras yang membentuk suatu komputer, peserta juga diajarkan bagaimana melakukan partisi harddisk dan menginstalasi sistem operasi, serta diajarkan juga teknik membangun LAN dan cara instalasinya.', ''),
(15, 'LAN', 'Wireless LAN Security', 2, 6, 'Kelas Wireless Security merupakan lanjutan dari materi Wireless LAN Standard dengan materi khusus yang lebih spesifik pada keamanan jaringan wireless dalam LAN dengan pengenalan jenis-jenis hardware yang terkait dengan kebutuhan sesuai materi. Wireless security merupakan sistem keamanan dalam menggunakan jaringan wireless. Sampai saat ini terdapat beberapa macam wireless security seperti WEP, WPA, WPA2 Enterprise dan WPA2 Personal.', ''),
(16, 'WIN1/001', 'MS. Office/OpenOffice/LibreOffice Advanced ', 3, 24, 'Materi training Ms. Office Advanced berisi lanjutan dari Ms. Office Complete standard. Materi ini berisi tentang penggunaan Microsoft Office atau LibreOffice dengan cakupan materi yang lebih dalam dan kompleks. Formula-formula yang telah dibahas pada paket Microsoft Office / LibreOffice Complete akan lebih dikembangkan lagi struktur formula dan fungsinya.', ''),
(17, 'WIN2/002', 'Ms. Office /OpenOffice/LibreOffice for Secret', 3, 24, 'Materi training Ms. Office / LibreOffice Complete ini adalah paket pelatihan dari modul-modul Microsoft Windows / Linux dan Microsoft / Libre Office yang paling banyak dipergunakan dalam pekerjaan sehari-hari. Mulai dari manajemen file, pembuatan aneka surat dan format naskah ~ baik untuk keperluan pribadi ataupun untuk keperluan dinas. Pembuatan pelaporan dalam bentuk tabel-tabel dan perhitungan-nya secara praktis. Mulai dari perhitungan sederhana sampai kepada analisa statistik dan keuangan serta visualiasi data dalam bentuk grafik. Alhamdulillah Produk Microsoft yang dipergunakan oleh NF COMPUTER ini sudah berlisensi.', ''),
(18, 'OFS', 'Ms. Office/OpenOffice/LibreOPffice for Secretary', 3, 24, 'Paket MS Office / LibreOffice for Secretary ini sengaja dirancang untuk memenuhi kebutuhan SDM perkantoran modern – khususnya dalam membekali tugas-tugas kesekretarisan yang banyak menggunakan aplikasi Office. Baik yang berbasis MS Windows maupun yang berbasis Open Source.\r\nHal ini perlu dilakukan, karena banyak para lulusan SMA/SMK yang berminat untuk bekerja di perkantoran tetapi masih minim skill mereka di bidang aplikasi office. Demikian juga para Junior Secretary – kebanyakan di antara mereka yang selama ini sudah terbiasa menggunakan aplikasi itu, hanyalah sebagai pengganti mesin ketik saja. Padahal banyak sekali fitur-fitur dalam aplikasi itu yang dapat memudahkan pekerjaan sehari-hari. Mulai dari penggunaan internet, pengaturan perjanjian dan agenda kerja, pembuatan dan pengiriman email, surat menyurat, makalah, proposal, lembar kerja elektronik & aplikasi database, sampai pada cara membuat dan mempersiapkan slide presentasi secara profesional.\r\n\r\n', ''),
(19, 'OFAW', 'Ms. Word/OpenOffice/LibreOffice For Academi', 3, 12, '', ''),
(20, 'WIN3/003', 'Presentasi Professional', 3, 16, 'Paket training Presentasi Profesional ini menitikberatkan kepada materi pembuatan slide presentasi yang menarik dan secara efektif dapat menyampaikan isi presentasi kepada audiens. Didalamnya akan dipelajari bagaimana teknik presentasi yang menarik, struktur slide presentasi yang baik, dan bagaimana menjadikan animasi flash menjadi sebuah tambahan nilai (added value) bagi tercapainya tujuan presentasi.\r\nProgram aplikasi yang digunakan pada paket training ini adalah Microsoft Powerpoint dan sebagai added value maka dibahas juga teknik pembuatan animasi menggunakan Flash dengan berbagai bentuk output file.', ''),
(21, 'MPJC', 'Ms. Projects', 3, 16, 'Materi training Microsoft Project adalah bagaimana mengatur jadwal dan mengelola proyek dengan cara monitoring tugas-tugas secara rinci dan akurat.', ''),
(22, 'PNAP', 'Program Network Administrator Professional(PNAP)', 4, 110, 'program ini ditujukan bagi mereka yang ingin memiliki keahlian dan kemampuan untuk berkarir di bidang jaringan komputer sebagai network administrator (pengelola jaringan komputer).\r\n\r\nProgram pendidikan dan latihan ini diselenggarakan dalam waktu 110 Jam. Metode pembelajaran yang diterapkan dalam program ini tidak hanya pada pengetahuan dan konsep saja tetapi berorientasi pada kemampuan praktis melalui praktikum dan latihan yang intensif. Dengan demikian program ini akhirnya diharapkan mampu menghasilkan tenaga atau sumber daya manusia yang memiliki pengetahuan dan kemampuan yang nyata dalam merancang, membangun dan mengelola jaringan komputer.\r\n\r\nProgram ini juga memberikan pengetahuan dan kemampuan praktis dalam mengelola sistem operasi linux. Pengetahuan tentang linux ini sangatlah relevan dengan tujuan dari program ini, karena pada kenyataannya jika berbicara tentang jaringan komputer dan infrastrukturnya, akan ditemukan banyak sekali penggunaan dan pemanfaatan sistem linux untuk digunakan sebagai server server dalam jaringan komputer. Untuk itu dibutuhkan kemampuan tambahan bagi seorang network administrator untuk dapat juga menginstal dan menglola sistem linux.\r\n\r\nProgram ini diselenggarakan berdasarkan kurikulum dan materi belajar yang dibuat sendiri oleh Lembaga Pendidikan dan Pengembangan Profesi Terpadu Nurul Fikri (LP3T-NF) dengan mempertimbangkan kebutuhan akan proses belajar yang intensif dan efektif.', ''),
(23, 'LPT1', 'LPIC-1 Certification Preparation(LPIC-1 Prep)', 4, 40, 'LPIC-1 Certification Preparation Class merupakan training resmi dari Linux Professional Institute (LPI) Canada dengan Nurul Fikri sebagai mitra kerjasama training resmi (ATP/Approved Training Partner) dan IOSN (International Open Source Network).\r\nLPIC-1 Preparation merupakan upaya persiapan untuk mencapai kelulusan dalam uji sertifikasi LPIC-1. Selain itu LPIC-1 Preparation mempersiapkan peserta untuk dapat menjadi seorang administrator sistem linux yang kompeten.\r\nLPIC-1 Adalah program sertifikasi profesional Linux yang terdiri dari dua unit ujian, yaitu Exam 101 dan Exam 102. Sertifikat LPIC diterima apabila peserta lulus dalam kedua exam tersebut.\r\nSertifikasi LPI diakui dunia internasional sebagai salah satu sertifikasi Linux terbaik dan menjadi rujukan sertifikasi internasional.', ''),
(24, 'LPT2', 'LPIC-1 Certification Preparation (LPIC-1 Prep) + EXAMS', 4, 40, '', ''),
(25, 'LPR', 'Linux Professional (LPro)', 4, 52, 'Menghasilkan SDM TI (teknologi informasi dan komputer) Profesional (Linux Professional) yang kreatif dan memiliki kemampuan untuk menginstal, menggunakan, membangun dan mengelola server dengan sistem operasi Linux.', ''),
(26, 'PHPP', 'PHP Professional (PHPro)', 4, 100, '', ''),
(27, 'JAVP', 'Java Professional (JAVAPro)', 4, 84, '', ''),
(28, 'PMP', 'Project Management Professional Fundamental', 4, 32, '', ''),
(29, 'QCAD', 'QCAD 2D', 5, 24, '', ''),
(30, 'FCAD', 'FreeCAD 3D', 5, 24, '', ''),
(31, 'CAD1', 'AutoCAD Standard ', 5, 30, 'AutoCAD Standard materi dasar grafis merancang bentuk suatu object dengan pembekalan materi 2D dan 3D untuk detail object bentuk yang lebih spesifik. AutoCAD adalah perangkat lunak komputer CAD untuk menggambar 2 dimensi dan 3 dimensi yang dikembangkan oleh Autodesk.\r\n\r\nFormat data asli AutoCAD, DWG, dan yang lebih tidak populer, Format data yang bisa dipertukarkan (interchange file format) DXF, secara de facto menjadi standard data CAD. Akhir-akhir ini AutoCAD sudah mendukung DWF, sebuah format yang diterbitkan dan dipromosikan oleh Autodesk untuk mempublikasikan data CAD.', ''),
(32, 'CAD2', 'AutoCAD Advanced', 5, 16, 'AutoCAD Advanced materi lanjutan seputar grafis merancang bentuk suatu object dengan pembekalan materi yang lebih mendalam 2D dan 3D untuk detail object bentuk yang lebih spesifik dengan kombinasi 2D & 3D dan lain-lain. AutoCAD adalah perangkat lunak komputer CAD untuk menggambar 2 dimensi dan 3 dimensi yang dikembangkan oleh Autodesk.\r\n\r\nFormat data asli AutoCAD, DWG, dan yang lebih tidak populer, Format data yang bisa dipertukarkan (interchange file format) DXF, secara de facto menjadi standard data CAD. Akhir-akhir ini AutoCAD sudah mendukung DWF, sebuah format yang diterbitkan dan dipromosikan oleh Autodesk untuk mempublikasikan data CAD.', ''),
(33, 'WEB1', 'Web Standard (HTML,CSS,& Javascript)', 6, 16, 'Web Standard (HTML, CSS & Javascript) pada materi training DHTML ini meliputi materi HTML, CSS dan JavaScript. HTML digunakan untuk mendesign halaman website. CSS digunakan untuk menata dokumen HTML yang pernah dibuat dan memperindah tampilan halaman web dengan style-style CSS. JavaScript digunakan untuk membangun website dinamis dengan pemograman yang berjalan di sisi web browser.\r\n\r\n', ''),
(34, 'PHP1', 'PHP & MySQL Standard', 6, 24, 'PHP MySQL Standard Materi training PHP dan MySQL standard ini memfokuskan pada penggunaan bahasa pemrograman web PHP dan database MySQL untuk membangun aplikasi database berbasis web ataupun website dengan mudah dan benar. Peserta diajarkan menggunakan sintak dan struktur bahasa PHP, meliputi tipe data, operator, dan perintah-perintah serta fungsi-fungsi built-in php. Peserta diajarkan bagaimana merancang database dan tabel di mysql, dan bagaimana menampilkan, menyimpan, mengupdate, serta mendelete data dalam database mysql. Peserta juga diajarkan bagaimana membuat script php yang mengakses database mysql.', ''),
(35, 'WEB2', 'Web Complete(WEB1 + PHP1, Hosting)', 6, 44, 'Materi training Web Complete ini merupakan gabungan dari paket Web Standard dan PHP & MySQL Standard. Yaitu sebuah kombinasi bahasa pemrograman web HTML, PHP dan database MySQL untuk membangun aplikasi database berbasis web yang interaktif. Peserta diajarkan menggunakan tag-tag HTML, sintak dan struktur bahasa PHP. Peserta diajarkan bagaimana merancang database dan tabel di mysql, serta bagaimana menampilkan, menyimpan, mengupdate, serta mendeletenya. Peserta juga diajarkan bagaimana membuat script PHP yang dapat mengakses database mysql.', ''),
(36, 'PHP3', 'PHP & AJAX', 6, 20, 'PHP & Ajax Materi training AJAX dan PHP ini memfokuskan pada implementasi teknologi AJAX pada sebuah aplikasi web dengan menggunakan bahasa pemrograman PHP. Diharapkan setelah mengikuti training ini siswa atau peserta kursus dapat memahami dan menggunakan CSS, JavaScript sebagai salah satu bagian dari teknologi AJAX serta menggunakan PHP sebagai pemrograman di sisi server dikombinasikan dengan teknologi AJAX.', ''),
(37, 'PHP4', 'PHP ORACLE', 6, 28, 'PHP Professional Siswa dibimbing dalam memahami dan mendalami pemrograman PHP dari dasar dan lebih mendalam, dimana peserta sebelumnya sudah menguasai dasar-dasar pemrograman PHP beserta sistem database MySQL, dan telah mampu menggunakan PHP & MySQL dasar dalam membuat program aplikasi tertentu untuk mendalami materi lebiih mendalam dengan berbagai studi kasus dan menjadi programmer PHP yang mampu menggunakan Framework', ''),
(38, 'WEB3', 'Web Instant (HTML, CSS, Wordpress, Joomla, Hosting)', 6, 24, 'Web Instant pada materi training ini meliputi materi HTML, CSS CMS Joomla! dan Blog WordPress. Peserta diajarkan menggunakan sintak HTML dan CSS, dan diajarkan penggunaan Content Management System (CMS) JOOMLA serta membuat Blog dengan WordPress', ''),
(39, 'WEB4', 'Web Design Interactive', 6, 36, 'Web Design Interactive pada materi training ini meliputi materi HTML, CSS CMS Joomla! dan Blog WordPress. Peserta diajarkan menggunakan sintak HTML dan CSS, dan diajarkan penggunaan Content Management System (CMS) JOOMLA serta membuat Blog dengan WordPress.\r\nSelain itu peserta didik dibimbing dalam mengenal, memahami dan menggunakan tool dan script di dalam Flash. Proses akhir dari pembelajaran Flash ini adalah peserta didik dapat membuat animasi yang menarik, program-program berbasis multimedia, dan mempublishnya menjadi berbagai bentuk tampilan khas Flash.\r\n', ''),
(40, 'SEO', 'SEO WEB', 6, 16, 'Search Engine Optimization (SEO) adalah serangkaian proses yang dilakukan secara sistematis yang bertujuan untuk meningkatkanvolume dan kualitas trafik kunjungan melalui mesin pencari menuju situs web tertentu dengan memanfaatkan mekanisme kerja atau algoritma mesin pencari tersebut. Tujuan dari SEO adalah menempatkan sebuah situs web pada posisi teratas, atau setidaknya halaman pertama hasil pencarian berdasarkan kata kunci tertentu yang ditargetkan. Secara logis, situs web yang menempati posisi teratas pada hasil pencarian memiliki peluang lebih besar untuk mendapatkan pengunjung.\r\n\r\nSejalan dengan makin berkembangnya pemanfaatan jaringan internet sebagai media bisnis, kebutuhan atas SEO juga semakin meningkat. Berada pada posisi teratas hasil pencarian akan meningkatkan peluang sebuah perusahaan pemasaran berbasis web untuk mendapatkan pelanggan baru. Peluang ini dimanfaatkan sejumlah pihak untuk menawarkan jasa optimisasi mesin pencari bagi perusahaan-perusahaan yang memiliki basis usaha di internet.', ''),
(41, 'PYT1', 'Python Programming Fundamental', 6, 32, 'Python adalah bahasa pemrograman interpreter yang dapat digunakan untuk mengembangkan atau membuat program atau aplikasi, mulai dari program atau aplikasi untuk sistem komputer, jaringan komputer sampai pada aplikasi sistem informasi berbasis web. Python memiliki struktur bahasa yang sangat sederhana, mudah digunakan dan banyak memiliki dukungan pustaka (libraries) yang memperkaya dan mempertangguh python sebagai bahasa pemrogram yang dapat digunakan untuk berbagai keperluan.\r\n\r\nPython adalah salah satu bahasa pemrograman yang bebas dan terbuka (free and open source software) dikembangkan oleh Guido van Rossum. Python kini telah menjadi bahasa pemrograman yang powerfull, dapat berjalan pada berbagai platform sistem operasi. Bahkan sebagian besar distribusi linux menjadikan python sebagai standar bahasa pengembangan program atau aplikasi yang disertakan langsung pada berbagai distribusi linux. Anda akan mendapati cukup banyak aplikasi jaringan, tool hacking, dan aplikasi atau program kontrol instrumentasi serta science memanfaatkan bahasa pemrograman python untuk pengembangannya.\r\n\r\nUntuk menghasilkan sumber daya manusia yang memiliki pengetahuan dan kemampuan praktis dalam mengembangkan program atau aplikasi berbasis python maka kami menyelenggarakan program pelatihan dan pendidikan pemrograman python fundamental yang diselenggrakan dalam waktu yang tidak terlalu lama, guna memberikan pemahaman, pengetahuan, keterampilan serta pengalaman nyata dalam membangun atau mengembangkan program atau aplikasi berbasis bahasa pemrograman python, Pelatihan python fundamental ini dirancang bukan hanya untuk diikuti oleh mereka yang sudah memiliki bekal pengetahuan programming, namun juga untuk dapat diikuti oleh programmer pemula atau mereka yang ingin menjadi programmer.', ''),
(42, 'PYT2', 'Python For System Adminstrator', 6, 40, 'Python for System Administration adalah bahasa pemrograman interpreter yang dapat digunakan untuk mengembangkan atau membuat program atau aplikasi, mulai dari program atau aplikasi untuk sistem komputer, jaringan komputer sampai pada aplikasi sistem informasi berbasis web. Python memiliki struktur bahasa yang sangat sederhana, mudah digunakan dan banyak memiliki dukungan pustaka (libraries) yang memperkaya dan mempertangguh python sebagai bahasa pemrogram yang dapat digunakan untuk berbagai keperluan.\r\n\r\nPython adalah salah satu bahasa pemrograman yang bebas dan terbuka (free and open source software) dikembangkan oleh Guido van Rossum. Python kini telah menjadi bahasa pemrograman yang powerfull, dapat berjalan pada berbagai platform sistem operasi. Bahkan sebagian besar distribusi linux menjadikan python sebagai standar bahasa pengembangan program atau aplikasi yang disertakan langsung pada berbagai distribusi linux.\r\n\r\nSeorang pengelola (sysadmin) sistem unix atau linux umumnya memerlukan keterampilan pemrograman, karena seringkali dalam melaksanakan tugasnya sebagai seorang system administrator berhadapan dengan kondisi atau situasi yang mengharuskan seorang sysadmin membuat atau mengembangkan sendiri tool atau program untuk membantu dan mengotomasi pekerjaan atau tugasnya sehari hari. Dan dikarenakan umunya sistem unix atau linux telah dilengkapi secara default dengan python interpreter maka sebagian besar mereka para sysadmin mengunakan python sebagai bahasa untuk membangun atau membuat tool atau program yang dibutuhkannya.\r\n\r\nPelatihan dan pendidikan python for system administration ini diselenggrakan untuk memberikan pengetahuan dan kemampuan praktis dan nyata bagi para sistem administrator atau juga network administrator dalam membantu memudahkan, mengoptimalkan dan mengotomasi pekerjaan atau tugas tugas mereka dalam aktifitas sehari hari. Peserta akan diberikan materi terkait pemrograman python untuk sistem dan jaringan.', ''),
(43, 'PHP(digant', 'PHP Yii Framework Fundamental', 7, 56, 'PHP Yii Framework Fundamental pada materi ini siswa dibimbing dalam memahami Pemrograman OOP dengan PHP5 dan menggunakan Framework dalam membuat aplikasi web. Framework yang digunakan adalah Yii Framework.', ''),
(44, 'PHP5', 'PHP Yii Framework Advanced', 7, 28, 'PHP Yii Framework Advanced pada materi ini siswa dibimbing dalam memahami Pemrograman OOP dengan PHP5 dan menggunakan Framework dalam membuat aplikasi web. Framework yang digunakan adalah Yii Framework.', ''),
(45, 'PHP6', 'PHP Zend Framework', 7, 28, '', ''),
(46, 'PHP7', 'PHP Codelgniter', 7, 28, 'PHP CodeIgniter Framework pada materi ini siswa dibimbing dalam memahami Pemrograman OOP dengan PHP5 dan menggunakan Framework dalam membuat aplikasi web. Framework yang digunakan adalah Code Igniter.', ''),
(47, 'PHP8', 'PHP Laravel Framework', 7, 28, 'PHP Laravel Framework – PHP Laravel Framework pada materi ini peserta dibimbing dalam memahami Pemrograman OOP dengan PHP5 dan menggunakan Framework dalam membuat aplikasi web. Framework yang digunakan adalah Code Igniter.', ''),
(48, 'JAV5', 'Java Zkoss Framework', 7, 28, '', ''),
(49, 'JAV6', 'Java Spring Framework', 7, 28, 'Materi training Java Framework mempelajari penggunaan kerangka kerja (framework) aplikasi web berbasis Java. Peserta diajarkan bagaimana menggunakan Web Framework Spring MVC beserta library aplikasi Java lainnya seperti JDBC, JSTL dan Library Spring Framework untuk membuat aplikasi bisnis berbasis web yang dinamis. Serta menggunakan library CSS untuk membangun aplikasi web yang responsive.', ''),
(50, 'ADROID1', 'Java for Android', 8, 16, 'Java for Android – materi training ini memfokuskan pada penggunaan bahasa pemrograman java untuk membangun aplikasi di Platform Ponsel Cerdas (Smartphone). Peserta dalam mengikuti paket Java for Android ini diajarkan konsep pemrograman di java, Class dan Object, Konsep Object Oriented Programming Java, Instalasi Android SDK, Konsep Pemrograman Android, Object dan Komponen Form, Design Layout, 2D dan multimedia.', ''),
(51, 'ADROID2', 'Android for Developer', 8, 20, 'Materi training Android for Developer ini memfokuskan pada penggunaan bahasa pemrograman java untuk membangun aplikasi di Platform Ponsel Cerdas (Smartphone). Instalasi Android SDK, Konsep Pemrograman Android, Object dan Komponen Form, Design Layout, 2D dan multimedia.', ''),
(52, 'ANDROID3', 'Android Complete(ANDRIOD1+ ANDROID2)', 8, 36, 'Materi training Pemrograman Android Complete ini memfokuskan pada penggunaan bahasa pemrograman java untuk membangun aplikasi di Platform Ponsel Cerdas (Smartphone). Peserta diajarkan konsep pemrograman di java, Class dan Object, Konsep Object Oriented Programming Java, Instalasi Android SDK, Konsep Pemrograman Android, Object dan Komponen Form, Design Layout, 2D dan multimedia.', ''),
(53, 'ANDROID4', 'Android Advanced', 8, 28, 'Materi Android Programming Advanced merupakan kelanjutan dari Android Programming. Pelatihan memfokuskan pada pembuatan aplikasi Android menggunakan fitur-fitur lanjutan yang memerlukan pengetahuan lebih, seperti pembacaaan status device, penggunaan media kamera dan penyimpanannya, pustaka Google Maps V2, hingga koneksi Android ke Web Service.', ''),
(54, 'ANDROID5', 'Android Hybrid(Ionic)', 8, 28, 'Android Hibryd materi training Android Hibryd ini membangun aplikasi di Platform Ponsel Cerdas (Smartphone). Peserta diajarkan konsep pemrograman dengan Ionic Framework.', ''),
(55, 'JAV1', 'Java Fundamental with Netbeans', 8, 28, 'Java Fundamental – Java Fundamental pada kelas ini peserta diajarkan menguasai programming dengan Java, salah satu yang populer dalam jenis pemrograman OOP yang dibutuhkan dunia kerja.', ''),
(56, 'JAV2', 'Java Web & JSF', 8, 28, 'Java Web & JSF materi  training Java Web Programming ini memfokuskan pada penggunaan lebih lanjut bahasa pemrograman java untuk membangun aplikasi database berbasis web. Peserta diajarkan dasar-dasar HTTP, Peserta juga diajarkan penulisan konsep pemrograman di java seperti Servlet dan JSP, teknik bekerja dengan JDBC, Konsep JavaBean dan Pengenalan Framework JSF', ''),
(57, 'JAV3 ', 'Java Complete (JAV1+JAV2)', 8, 56, '\r\nJava Complete – Materi training Java Complete adalah gabungan dari traning Java Fundamental dan Java Web Programming dan JSF. Peserta diajarkan mulai dari dasar-dasar algoritma pemrograman dengan Java hingga membuat aplikasi web yang terkoneksi ke database. Peserta juga diperkenalkan dengan Framework Web JSF. Selama belajar peserta diajarkan menggunakan perintah commandline dan menggunakan IDE NetBeans.', ''),
(58, 'SQL1', 'MySQL', 9, 20, 'Program yang membimbing siswa dalam memperdalam Database MySQL yang meliputi pengenalan dan konsep database, Model relational database, DDL dan DML, JOIN Table, Fungsi Aggregate, VIEW, TRIGGER dan Store Procedure, juga mempelajari Manajemen User dan Izin akses Database, Backup dan Restore database.', ''),
(59, 'SQL2', 'Ms. SQL Server', 9, 20, 'Ms. SQL Server Program yang membimbing siswa dalam memperdalam Database MSQL Server yang meliputi pengenalan dan konsep database, Model relational database, DDL dan DML SQL pada SQL Server, Menggunakan TSQL Server, VIEW, TRIGGER dan Store Procedure, juga mempelajari Manajemen User dan Izin akses Database, Backup dan Restore database.', ''),
(60, 'SQL3', 'PostgreSQL', 9, 20, 'Program yang membimbing siswa dalam memperdalam Database PostgreSQL yang meliputi pengenalan dan konsep database, Model relational database, DDL dan DML, JOIN Table, Fungsi Aggregate, VIEW, TRIGGER dan Store Procedure, juga mempelajari Manajemen User dan Izin akses Database, Backup dan Restore database', ''),
(61, 'SQL4', 'SQL Oracle', 9, 20, 'SQL with Oracle adalah program yang membimbing siswa dalam memperdalam database Oracle yang meliputi pengenalan dan konsep database, Model relational database, DDL dan DML, JOIN Table, Fungsi Aggregate, VIEW,  dan TRIGGER.', ''),
(62, 'ORC1', 'Oracle Administration I - Fundamental', 9, 20, '', ''),
(63, 'ORC2', 'Oracle Administration I - Advanced', 9, 20, '', ''),
(64, 'ACC1', 'Ms. Access Standard', 9, 16, 'Ms. Access Standard adalah program training yang akan membimbing peserta untuk menguasai aplikasi Microsoft Access (aplikasi database) secara efektif dan efisien sesuai dengan kebutuhan dunia kerja pada umumnya di lingkungan perkantoran, kelas ini merupakan aplikasi database untuk input data ke dalam server dengan konten-konten yg terstruktur sesuai dengan kebutuhan', ''),
(65, 'ACC2', 'Ms. Access Programming ', 9, 20, '', ''),
(66, 'INFGRAPH', 'InfoGraphics', 10, 16, '', ''),
(67, 'VIDEO', 'Video Editing with Adobe Premiere', 10, 12, 'Video Editing with Adobe Premiere & After Effect – Materi training Video Editing with Adobe Premiere & After Effect ini memfokuskan pada penggunaan aplikasi untuk melakukan modifikasi video dan pembuatan film singkat. Peserta diajarkan menggunakan aplikasi Adobe Premiere untuk melakukan editing video (menggabungkan beberapa video menjadi satu film/dokumentasi, menambahkan background, sound, dan obyek multimedia lain). Peserta juga diajarkan menggunakan aplikasi Adobe After Effect untuk membuat animasi bergerak.', ''),
(68, 'BLEND1', 'Modeling Animation with Blender', 10, 16, 'Kelas khusus desain grafis menggunakan program aplikasi animasi 3 dimensi Blender. Program aplikasi berbasis Open Source ini akan digunakan untuk membuat berbagai bentuk gambar 3 dimensi dan file animasi sederhana.\r\nSetelah selesai training, peserta diharapkan dapat membuat model-model 3 dimensi sederhana dan mengatur pergerakannya dalam animasi frame by frame.', ''),
(69, 'BLEND2', 'Architecture Animation with Blender', 10, 16, 'Merupakan lanjutan dari kelas Modelling Animation dengan fokus pembelajaran ke arah pembuatan model-model arsitektur dan berbagai bentuk propertinya. Animasi yang dihasilkan lebih banyak menggunakan teknik Walk Through dan Tracking.\r\nSetelah selesai training, peserta diharapkan dapat membuat model-model 3 dimensi di bidang arsitektur dan mengatur pergerakannya menjadi sebuah animasi walkthrough.', ''),
(70, 'BLEND3', '3D Character Animation with Blender', 10, 16, ' Level tertinggi dari paket animasi 3 dimensi  menggunakan  Blender. Akan  dibahas  teknik  pembuatan  karakter  dan  animasinya.  Termasuk efek-efek khusus menggunakan Particle, Physics, dan Open GL. Setelah  selesai  training,  peserta  diharapkan  dapat  membuat  berbagai bentuk  karakter  3  dimensi  dan  membuat  pergerakannya  menjadi sebuah film animasi.', ''),
(71, 'GIMP', 'Photo Editing with Gimp / Adope Photoshop', 10, 24, 'Materi training Photo & Image Editing with GIMP/Photoshop ini memfokuskan pada penggunaan aplikasi untuk melakukan modifikasi gambar & foto menggunakan fitur-fitur yang ada dalam aplikasi GIMP. Dimulai dari pengenalan tools, seleksi tingkat dasar, penggunaan curve, filter-filter hingga ke seleksi tingkat mahir (dengan menggunakan masking dan channel).\r\nPeserta juga akan diajarkan bagaimana cara membuat publikasi yang menarik. Setelah selesai training, peserta diharapkan dapat mengaplikasikan ilmunya menjadi seorang Desainer kreatif (membuka usaha sendiri / sebagai profesional).', ''),
(72, 'SCR', 'Desktop Publishing with Scribus / Adobe InDesign', 10, 12, 'Materi training Desktop Publishing with Scribus/inDesign ini memfokuskan pada penggunaan aplikasi untuk membuat layout suatu publikasi (buku, majalah, bulletin, dsb). Peserta juga diajarkan tentang cara membuat Master Document, menggunakan gambar kedalam publikasi, export ke format lain.', ''),
(73, 'INKS1', 'Vector Graphic Editor with Inkscape / CorelDRAW', 10, 12, 'Materi training Vector Graphic Editing dengan Inkscape/CorelDraw ini memfokuskan pada penggunaan aplikasi untuk membuat dan memodifikasi gambar vektor menggunakan fitur-fitur yang ada dalam aplikasi Inkscape. Dimulai dari pengenalan interface & tools, pembuatan gambar vector, komposisi warna, dan pemanfaatan beberapa efek gambar untuk menciptakan gambar vector yang menarik.', ''),
(74, 'INKS2', 'Graphic Design Complete (Adobe Photoshop , InDesign, CorelDRAW)', 10, 40, 'Peserta didik dibimbing untuk mengenal dan menguasai software-software yang biasa digunakan untuk membuat dan mengolah gambar. Sistem pembelajaran yang digunakan berupa pengerjaan proyek-proyek desain grafis sesuai dengan kebutuhan terkini.', ''),
(75, '-', 'Bahasa Inggris', 6, 23, '-', '-'),
(76, '1', 'Administrasi Basis Data', 9, 46, '-', '-'),
(77, '2', 'Microsoft Excel Basic-Intermediate', 3, 14, '', ''),
(78, '3', 'Microsoft Excel Advanced', 3, 14, '-', '-'),
(79, '4', 'Teknis Manajemen Database PostreSQL', 9, 20, '-', '-'),
(80, '6', 'Office Complete', 3, 24, '-', '-'),
(81, '7', 'UX', 6, 32, '-', '-'),
(82, '8', 'Anguler', 6, 32, '-', '-'),
(83, '9', 'Leaflet', 13, 32, '-', '-'),
(84, '10', 'Pemrogaman R', 13, 8, '-', '-'),
(85, 'FC001', 'Fun Coding', 13, 20, '', ''),
(86, 'ALGO', 'Pengantar Algoritma', 13, 20, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1541442610),
('m140209_132017_init', 1541442619),
('m140403_174025_create_account_table', 1541442619),
('m140504_113157_update_tables', 1541442621),
('m140504_130429_create_token_table', 1541442621),
('m140506_102106_rbac_init', 1541453214),
('m140602_111327_create_menu_table', 1541452985),
('m140830_171933_fix_ip_field', 1541442622),
('m140830_172703_change_account_table_name', 1541442622),
('m141222_110026_update_ip_field', 1541442623),
('m141222_135246_alter_username_length', 1541442623),
('m150614_103145_update_social_account_table', 1541442624),
('m150623_212711_fix_username_notnull', 1541442624),
('m151218_234654_add_timezone_to_profile', 1541442625),
('m160312_050000_create_user', 1541452985),
('m160929_103127_add_last_login_at_to_user_table', 1541442625),
('m170907_052038_rbac_add_index_on_auth_assignment_user_id', 1541453214);

-- --------------------------------------------------------

--
-- Table structure for table `pengajar`
--

CREATE TABLE `pengajar` (
  `id` int(11) NOT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `nama` varchar(45) NOT NULL,
  `kategori` enum('Internal','Eksternal','Freelance') NOT NULL,
  `gender` enum('L','P') NOT NULL,
  `tmpLahir` varchar(45) DEFAULT NULL,
  `tglLahir` date DEFAULT NULL,
  `alamat` text,
  `email` varchar(45) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `foto` varchar(45) DEFAULT NULL,
  `cv` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengajar`
--

INSERT INTO `pengajar` (`id`, `nip`, `nama`, `kategori`, `gender`, `tmpLahir`, `tglLahir`, `alamat`, `email`, `hp`, `foto`, `cv`) VALUES
(4, '1131286201', 'Ahmad Rio Ardiansyah, S.Si. M.Si', 'Internal', 'L', 'Pekalongan', '1986-09-13', '', '-', '081573954126', '1131286201-832019.jpg', ''),
(5, '1260487001', 'April Rustianto ', 'Freelance', 'L', 'Cilacap', '1987-04-26', '-', 'april@gmail.com', '-', '1260487001-20112018.jpg', NULL),
(6, '1070974201', 'Henry Saptono, S.Si., M.Kom', 'Internal', 'L', 'Jakarta', '1974-09-07', 'Jl. H Rijin, Kp Kelapa dua Rt 05/11 Cimanggis Depok\r\n', 'henry@nurulfikri.com  ', '+628158984709', '1070974201-23112018.jpg', NULL),
(7, '1111184201', 'Hilmy Abidzar Tawakal, ST., M.Kom', 'Internal', 'L', 'Jakarta', '1984-11-11', '-', 'hilmi@gmail.com', '-', '1111184201-832019.jpg', NULL),
(8, '1130387201', 'Indra Hermawan, M.Kom', 'Eksternal', 'L', 'Majalengka', '1987-11-13', '-', 'Indra@gmail.com', '-', '1130387201-832019.png', NULL),
(9, '1230763201', 'Drs. Rusmanto, M.M.', 'Internal', 'L', 'Sragen', '1963-11-23', '-', 'rus@nurulfikri.ac.id', '08159029992', '1230763201-832019.jpg', NULL),
(10, '1140471201', 'Sirojul Munir, S.Si, M.Kom', 'Internal', 'L', 'Jakarta', '1971-04-14', '-', 'sirojulmunir@gmail.com', '-', NULL, NULL),
(11, '1060672201', 'Suhendi, ST, MMSI', 'Internal', 'L', 'Jakarta', '1972-06-06', '-', 'suhendi@gmail.com', '081380006672', '1060672201-832019.jpg', NULL),
(12, '1010171201', 'Warsono, S.Kom., MTI', 'Freelance', 'L', 'Purwakarta', '1971-01-01', 'asdas', 'warsono@gmail.com', 'asdasd', '', ''),
(13, '1260883201', 'Zaki Imaduddin S.T, M.Kom', 'Internal', 'L', 'Jakarta', '1983-08-26', '-', 'zaki@gmail.com', '-', NULL, NULL),
(14, '1240771001', 'Efrizal Zaida ', 'Freelance', 'L', 'Tanjung Alam', '1971-07-24', '-', 'efrizal@gmail.com', '-', NULL, NULL),
(15, '1081090101', 'Edo Riansyah, S.Kom', 'Internal', 'L', 'Bogor', '1990-10-08', '-', 'edo@gmail.com', '-', NULL, NULL),
(16, '1120782101', 'Hendra Sasmita, S.Kom, M.TI', 'Freelance', 'L', 'Bogor', '1982-07-12', '-', 'hendra@gmail.com', '-', NULL, NULL),
(17, '1010885101', 'Danil Syahrizal ', 'Internal', 'L', 'Bogor', '1985-08-01', '-', 'dani@gmail.com', '-', NULL, NULL),
(18, '1101080101', 'Nasrul,S.Pd.I., S.Kom., M.Kom.', 'Internal', 'L', 'Jakarta', '1980-10-10', 'Jl. Jatijajar II Komplek Linux Asri Blok A No.9 Rt. 04/08 Tapos, Jatijajar, Depok\r\n', 'nasrul99@gmail.com', '085780844411', '1101080101-832019.jpg', '1101080101.docx'),
(19, '1271083001', 'Toto Harjendro', 'Freelance', 'L', 'Jakarta', '1983-10-27', '-', 'toto@gmail.com', '-', NULL, NULL),
(20, '1130381101', 'Hafidz Atamim, S.Kom', 'Eksternal', 'L', 'Jakarta', '1981-03-13', 'Cililitan Kecil 1 No.9 B Rt.016/07 Kramat Jati Jakarta Timur\r\n', 'hafidzlp3tnf@gmail.com', '-', NULL, NULL),
(21, '1040578101', 'Achmad Ilham, S.Kom', 'Internal', 'L', 'Jakarta', '1978-05-04', 'JL. Malawi 1 No. 88 Depok-Timur 16417\r\n', 'ilham@nurulfikri.com', '-', '1040578101-122019.jpg', NULL),
(22, '1180574101', 'Daseh Hidayat', 'Eksternal', 'L', 'Bandung', '1974-05-18', 'Komp.Timah Blok CC I/1 Rt.05/12 Cimanggis Depok\r\n', 'daseh@nurulfikri.com  ', '-', '1180574101-832019.jpg', NULL),
(23, '1060476101', 'Sugandi, S.T', 'Internal', 'L', 'Cirebon', '1976-04-06', 'Jl.Kalisari Lapan Gg.Sawi No.23 Rt.02/01 Pekayon Ps.Rebo\r\n', 'gandinf7799@gmail.com', '083874895833', '1060476101-122019.jpg', NULL),
(24, '2260892101', 'Laisa Nurin Mentari, S.Kom', 'Internal', 'P', 'Jakarta', '1992-01-26', 'Kesatrian Ditlantas RT 001/RW 002 No. 44, Pejaten Barat, Pasar Minggu\r\n', 'laisa@nurulfikri.co.id', '-', '2260892101-29112018.png', NULL),
(25, '1140997101', 'Choniyu Azwan', 'Internal', 'L', 'Bangun Sari', '1997-09-14', 'Kabupaten Batu Bara, Sumatera Utara. Domisili: Cimanggis-Depok\r\n', 'choniyu.azwan@unf.ac.id', '-', NULL, NULL),
(26, '1160589101', 'Rifqi Hilman', 'Internal', 'L', 'Jakarta', '1986-05-16', 'Jl. Mawar III RT 005/005 No.4, Rempoa Bintara\r\n', 'rifqi165@gmail.com', '-', NULL, NULL),
(27, '-', 'Hasna Mujahidah Amatullah', 'Freelance', 'P', '', NULL, '', 'hasnamujahidah@gmail.com', '-', NULL, NULL),
(29, '0', 'Wahyu Januar Alfian', 'Internal', 'L', '-', NULL, '-', 'wahyu@gmail.com', '-', NULL, NULL),
(30, '0', 'Dudi Fitrahadi', 'Internal', 'L', '-', NULL, '-', 'dudi@gmail.com', '-', NULL, NULL),
(31, '0', 'Dudi Fitrahadi', 'Internal', 'L', '-', NULL, '-', 'fiytahadi@gmail.com', '-', NULL, NULL),
(32, '-', 'Yuliadi, A.Md.', 'Internal', 'L', '-', NULL, '-', 'yuliadi@nurulfikri.com', '085213888063', '--832019.jpg', NULL),
(33, '-', 'Prana', 'Internal', 'L', '-', NULL, '-', 'prana@gmail.com', '-', NULL, NULL),
(34, '-', 'Ahmad Arif', 'Internal', 'L', '-', NULL, '-', 'ahmad@gmail.com', '-', NULL, NULL),
(35, '0', 'Wahyu Mubarok', 'Internal', 'L', '-', NULL, '-', 'wahyumubarok@gmail.com', '-', NULL, NULL),
(36, '-', 'Hendra Aditya', 'Internal', 'L', '-', NULL, '-', 'hendraaditya@gmail.com', '-', NULL, NULL),
(37, '-', 'M. Luqni Baihaqi', 'Internal', 'L', '-', NULL, '-', 'luqni@gmail.com', '-', NULL, NULL),
(38, '0', 'Nanang Kuswana', 'Eksternal', 'L', '-', NULL, '-', 'nanangkuswana@gmail.com', '-', NULL, NULL),
(39, '-', 'Bahni Mahariasha', 'Internal', 'L', '-', NULL, '-', 'bahni@gmail.com', '-', NULL, NULL),
(40, '2030797101', 'Yolanda Erziana', 'Internal', 'P', 'Padang', '1997-07-03', 'Jln Akses UI no.33 Cimanggis Depok', 'yolanda@nurulfikri.com', '082218332279', '2030797101-122019.jpg', '2030797101.pdf'),
(41, '-', 'Irfan Assidik, S.Kom.', 'Freelance', 'L', '', NULL, '', 'noemail', '0857xxx', NULL, NULL),
(42, '-', 'Ahadiyat, S.Sos, M.M.', 'Eksternal', 'L', '', NULL, '', 'ahadiyat@nurulfikri.ac.id', '-', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_id` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci,
  `timezone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`user_id`, `name`, `public_email`, `gravatar_email`, `gravatar_id`, `location`, `website`, `bio`, `timezone`) VALUES
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `social_account`
--

CREATE TABLE `social_account` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `code` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `user_id` int(11) NOT NULL,
  `code` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL,
  `type` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`user_id`, `code`, `created_at`, `type`) VALUES
(2, 'M7vDsLSq8pDBX1wlxc4z9blRgKCFoofo', 1543172230, 0),
(5, 'JFABwIDkgeeKGGxwExoIkj-Y91ovwdz7', 1550547060, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `confirmed_at` int(11) DEFAULT NULL,
  `unconfirmed_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blocked_at` int(11) DEFAULT NULL,
  `registration_ip` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `last_login_at` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password_hash`, `auth_key`, `confirmed_at`, `unconfirmed_email`, `blocked_at`, `registration_ip`, `created_at`, `updated_at`, `flags`, `last_login_at`, `status`, `password_reset_token`) VALUES
(2, 'laisa', 'laisa@nurulfikri.co.id', '$2y$12$S3eUJl7j6iNhwqVu91QPrebxmeIESr8lbyf.umOXN873pOdpxJs22', 'dCJV053w5Xo7UZ3jV-HsmmcfecrEBA8I', 1543172789, NULL, NULL, '::1', 1543172230, 1550547138, 0, 1553846036, 10, NULL),
(5, 'nasrul', 'nasrul99@gmail.com', '$2y$12$1ZIzykdiDM9efd3cS3CumuNdDA0texfq1Sutdp6UGt2Zp/4gqsome', 'nq8UyiELhBZgsRZZxUVqPiyhSAihVM1N', 1550547119, NULL, NULL, '::1', 1550547060, 1550547060, 0, 1552889723, 10, NULL),
(6, 'henry', 'henry@nurulfikri.ac.id', '$2y$12$.7ScSyYJ27STp8CVgi61mu0Z3UnaAPxJOv95SDedY4/oU9s4uASZe', '7WoFMlOYhgCKdWSPM3O1WWJs8BVKbP4W', 1552025638, NULL, NULL, '::1', 1552025638, 1552025638, 0, NULL, NULL, NULL),
(7, 'camal', 'camal@nurulfikri.com', '$2y$12$wCj6i5HIinJV4W9gnZXXAeLJo0gvNXyKZB2YA9L1OCXBHQt1qvdnO', 'oaJO0cbIhHBkvp-s4l0ytfOAkZKrLCKe', 1552027996, NULL, NULL, '::1', 1552027995, 1552027995, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure for view `jadwaltraining_v`
--
DROP TABLE IF EXISTS `jadwaltraining_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `jadwaltraining_v`  AS  select `k`.`nama` AS `kategori`,`m`.`nama` AS `materi`,`jt`.`tglMulai` AS `tglMulai`,`jt`.`tglAkhir` AS `tglAkhir`,`jt`.`hariBerjalan` AS `hariBerjalan`,`jt`.`jamMulai` AS `jamMulai`,`jt`.`jamAkhir` AS `jamAkhir`,`jt`.`durasi` AS `durasi`,`jt`.`lokasi` AS `lokasi`,`jt`.`jmlPeserta` AS `jmlPeserta`,`p`.`nama` AS `pengajar`,`jt`.`asisten` AS `asisten`,`jk`.`nama` AS `jenis_kelas`,`c`.`nama` AS `klien` from (((((`jadwaltraining` `jt` join `materi` `m` on((`m`.`id` = `jt`.`idMateri`))) join `kategori` `k` on((`k`.`id` = `m`.`idKategori`))) join `jeniskelas` `jk` on((`jk`.`id` = `jt`.`idJenisKelas`))) join `klien` `c` on((`c`.`id` = `jt`.`idKlien`))) join `pengajar` `p` on((`p`.`id` = `jt`.`idPengajar`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`),
  ADD KEY `auth_assignment_user_id_idx` (`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `detail_jadwal`
--
ALTER TABLE `detail_jadwal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idjadwal_idx` (`id`),
  ADD KEY `idjadwal` (`idjadwal`);

--
-- Indexes for table `jadwaltraining`
--
ALTER TABLE `jadwaltraining`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pengajar_has_materi_pengajar1` (`idPengajar`),
  ADD KEY `fk_pengajar_has_materi_materi1` (`idMateri`),
  ADD KEY `fk_training_jenisKelas1` (`idJenisKelas`),
  ADD KEY `fk_training_klien1` (`idKlien`);

--
-- Indexes for table `jeniskelas`
--
ALTER TABLE `jeniskelas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`);

--
-- Indexes for table `klien`
--
ALTER TABLE `klien`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `materi`
--
ALTER TABLE `materi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`),
  ADD UNIQUE KEY `kode_UNIQUE` (`kode`),
  ADD KEY `fk_materi_kategori` (`idKategori`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `pengajar`
--
ALTER TABLE `pengajar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `social_account`
--
ALTER TABLE `social_account`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_unique` (`provider`,`client_id`),
  ADD UNIQUE KEY `account_unique_code` (`code`),
  ADD KEY `fk_user_account` (`user_id`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD UNIQUE KEY `token_unique` (`user_id`,`code`,`type`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_unique_username` (`username`),
  ADD UNIQUE KEY `user_unique_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_jadwal`
--
ALTER TABLE `detail_jadwal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `jadwaltraining`
--
ALTER TABLE `jadwaltraining`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `jeniskelas`
--
ALTER TABLE `jeniskelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `klien`
--
ALTER TABLE `klien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `materi`
--
ALTER TABLE `materi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `pengajar`
--
ALTER TABLE `pengajar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `social_account`
--
ALTER TABLE `social_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `detail_jadwal`
--
ALTER TABLE `detail_jadwal`
  ADD CONSTRAINT `detail_jadwal_ibfk_1` FOREIGN KEY (`idjadwal`) REFERENCES `jadwaltraining` (`id`);

--
-- Constraints for table `jadwaltraining`
--
ALTER TABLE `jadwaltraining`
  ADD CONSTRAINT `fk_pengajar_has_materi_materi1` FOREIGN KEY (`idMateri`) REFERENCES `materi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pengajar_has_materi_pengajar1` FOREIGN KEY (`idPengajar`) REFERENCES `pengajar` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_training_jenisKelas1` FOREIGN KEY (`idJenisKelas`) REFERENCES `jeniskelas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_training_klien1` FOREIGN KEY (`idKlien`) REFERENCES `klien` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `materi`
--
ALTER TABLE `materi`
  ADD CONSTRAINT `fk_materi_kategori` FOREIGN KEY (`idKategori`) REFERENCES `kategori` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `fk_user_profile` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `social_account`
--
ALTER TABLE `social_account`
  ADD CONSTRAINT `fk_user_account` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `token`
--
ALTER TABLE `token`
  ADD CONSTRAINT `fk_user_token` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
